$p = @{
    Name        = "ImportExcel"
    NuGetApiKey = $NuGetApiKey
}

Publish-Module @p