. $PSScriptRoot\Get-StockInfo.ps1

Get-StockInfo -symbols "msft,ibm,ge,xom,aapl" -dataPlot avgTotalVolume