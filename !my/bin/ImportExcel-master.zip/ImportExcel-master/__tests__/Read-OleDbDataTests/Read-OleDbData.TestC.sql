select
  *
from
  [sheet1$A1:E10]
